// 以下为blog页面的核心结构的js代码
{
    let navItems = document.querySelectorAll(".nav li");
    let navLinks = document.querySelectorAll(".nav li a");

    // 1. 定义切换高亮的函数
    function setActiveLink(targetId) {
    // 先移除所有 active
    navItems.forEach((item) => item.classList.remove("active"));

    // 遍历所有链接，寻找 href 等于 targetId 的那个
    navLinks.forEach((link) => {
        // 获取链接的 href (例如 "#about-skills")
        let linkHref = link.getAttribute("href");
        
        // 如果匹配成功
        if (linkHref === targetId) {
            // 给对应的 li 添加 active 类
            link.parentElement.classList.add("active");
        }
    });
    }

    // 2. 页面加载时立即执行一次检查
    function initActiveLink() {
    // 如果没有 hash，默认设为第一个元素的 href (通常是 "#goohv-coding-word" 或 "#my-home")
    let currentHash = window.location.hash;

    if (currentHash) {
        setActiveLink(currentHash);
    } else {
        // 如果 URL 没有 # 号，默认高亮第一个菜单项（或者你可以指定高亮 "主页"）
        // 这里我们默认高亮列表中的第一个 li
        if(navItems.length > 0) {
            navItems[0].classList.add("active");
        }
    }
    }

    // 3. 绑定点击事件
    navItems.forEach((item) => {
    item.addEventListener("click", function(e) {
        // 【新增判断】如果点击的元素包含 'friend-links-container' 类名，则直接返回，不执行高亮
        if (this.classList.contains('friend-links-container')) {
            return; 
        }
        
        // 移除所有 active
        navItems.forEach((i) => i.classList.remove("active"));
        // 给当前点击的添加 active
        this.classList.add("active");
    });
    });

    // 4. 页面加载完成后初始化
    window.addEventListener('DOMContentLoaded', initActiveLink);
}

