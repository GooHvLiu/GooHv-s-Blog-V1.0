     
    // 简单的打字机脚本
    const textToType = "Equipment Development | Technical Sharing | Open Source";
    const typingElement = document.getElementById('typing-text');
    let index = 0;

    function type() {
        if (index < textToType.length) {
            typingElement.textContent = typingElement.textContent + textToType.charAt(index);
            index++;

            // 打字速度调整，此处为100ms延迟每个字符
            setTimeout(type, 100); 
        }
    }

    // 页面加载完成后开始打字
    window.onload = type;