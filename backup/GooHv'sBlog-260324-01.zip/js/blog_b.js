// ==========================================
// 【全局配置区】在此处定义 ID 与 文件路径 的对应关系
// ==========================================
const PAGE_PATH_MAP = {
    "my-home": "./pages/home.html",
    "full-stacked": "./pages/fullstacked.html",
    "tools-skills": "./pages/skills.html",
    "about-donation": "./pages/donate.html"
};

const DEFAULT_PAGE_PATH = "pages/404.html"; 
// ==========================================


// ==========================================
// Step 1：系统加载并初始化页面
// 页面加载完成后的初始化逻辑
// 作用：等 HTML 骨架搭好后，再给它们绑定事件监听器
// ==========================================
document.addEventListener('DOMContentLoaded', () => {

    // 【准备数据】再次获取所有导航项和所有板块 (section)，供后面使用，避免重复查找
    let navItems = document.querySelectorAll(".nav li");
    let sections = document.querySelectorAll("section");

    // --- 功能 1: 点击菜单时的高亮逻辑 ---
    // 遍历每一个导航项，给它绑定“点击”事件监听器
    navItems.forEach((item) => {
        item.addEventListener("click", function(e) {
            
            // 【特殊拦截】如果点击的这个 <li> 是“友情链接容器”，则什么都不做，直接返回。目的：防止友情链接被误认为是普通菜单而高亮
            if (this.classList.contains('friend-links-container')) {
                return; 
            }

            // ✅ 关键步骤：阻止浏览器默认的跳转行为（防止地址栏瞬间变化触发其他监听器）
            e.preventDefault(); 
            
            // 【手动清场】移除所有导航项的 active 类（这里是为了点击瞬间立即生效，不依赖updateActiveLink） 
            navItems.forEach((i) => i.classList.remove("active"));
            
            // 【手动点亮】给当前被点击的这个 <li> 添加 active 类
            this.classList.add("active");
        });
    });

    // --- 功能 2: 滚动时自动切换高亮 (滚动监听) ---
    // 监听窗口的滚动事件，用户一滚就触发
    window.addEventListener('scroll', () => {

         // 用于暂存当前应该高亮的那个板块的 ID
        let currentSectionId = '';

        // 获取当前页面向下滚动的像素距离
        let scrollPosition = window.scrollY || window.pageYOffset;

        // 遍历页面上所有的 <section> 板块
        sections.forEach(section => {

             // 计算这个板块距离页面顶部的距离
            const sectionTop = section.offsetTop;

            // 【核心算法】判断：如果滚动位置 >= (板块顶部 - 150像素)
            // 为什么要减 150？这是“偏移量”。因为你的侧边栏或顶部可能有固定高度，
            // 我们希望板块还没完全到顶时，就算它“激活”了，体验更顺滑。
            if (scrollPosition >= (sectionTop - 150)) {

                // 如果满足条件，更新 currentSectionId 为当前这个板块的 ID
                // 因为是从上往下遍历，后面的会覆盖前面的，所以最终得到的是“最靠上且已越过阈值”的那个板块
                currentSectionId = section.getAttribute('id');
            }
        });

         // 【执行更新】如果找到了有效的板块 ID，调用工具函数去更新菜单高亮
        if (currentSectionId) {
            updateActiveLink(currentSectionId);
        }
    });

    // --- 功能 3: 页面初始化时的状态检查 ---
    // 定义一个函数，用于处理刚打开页面时的情况（比如带了 #hash 的链接，或者直接刷新）
    const initCheck = () => {

        // 获取地址栏里的哈希值 (例如 #home)
        const hash = window.location.hash;
        if (hash) {
            
            // 情况 A：地址栏有 hash (比如用户分享了带 #contact 的链接)
            // 尝试找到对应的板块
            let targetSection = document.querySelector(hash);
            if (targetSection) {
                // 如果找到了，手动触发一次 'scroll' 事件
                // 这会强制运行上面的“滚动监听”逻辑，从而自动高亮对应的菜单，并可能触发滚动定位
                window.dispatchEvent(new Event('scroll'));
            }
        } else {
             // 情况 B：地址栏没 hash (用户直接访问首页)
            // 同样触发一次 'scroll' 事件
            // 这会让代码去判断当前滚动位置（通常是0），从而默认高亮第一个可见的板块）
            window.dispatchEvent(new Event('scroll'));
        }
    };

    // 【延迟执行】设置 100 毫秒 后执行 initCheck
    // 为什么要延迟？因为图片加载或字体渲染可能会影响页面布局高度 (offsetTop)。
    // 稍微等一小会儿，确保所有尺寸计算准确了，再执行高亮逻辑，防止高亮错位置。
    setTimeout(initCheck, 100);
});

// ==========================================
// Step 2：点击菜单或者滚动菜单后的加载响应事件
// 全局工具函数：更新菜单高亮状态
// 作用：无论是因为“点击菜单”还是“滚动页面”，只要需要改变高亮，都调用这个函数
// ==========================================
function updateActiveLink(targetId) {

    console.log("我是加载响应函数，目前的targetId是："+targetId);
    
    // 【获取元素】选中导航栏 (.nav) 下所有的 <li> 标签，注意：这里获取的是列表项容器，不是 <a> 链接本身
    let navItems = document.querySelectorAll(".nav li");
    
    // 【步骤1：清场】遍历所有 <li>，移除它们身上的 "active" 类，目的：确保同一时间只有一个高亮，防止出现“两个菜单都亮”的bug
    navItems.forEach(item => item.classList.remove("active"));

    // 【步骤2：定位】根据传入的 ID (例如 "home")，寻找对应的 <a> 标签。选择器逻辑：找 .nav 下的 li 里的 a，且 href 属性等于 "#目标ID"
    // 例如：targetId="home" -> 查找 <a href="#home">
    let activeLink = document.querySelector(`.nav li a[href="#${targetId}"]`);
    
    // 【安全检查】如果找到了这个链接（防止传入了不存在的ID导致报错）
    if (activeLink) {
        
        // 【特殊过滤】再次确认：这个链接的父级 (<li>) 是否包含 'friend-links-container' 类？目的：如果是“友情链接”区域，我们不想让它像普通菜单那样高亮，所以跳过
        if (!activeLink.parentElement.classList.contains('friend-links-container')) {
            activeLink.parentElement.classList.add("active");
        }
    }
    // 如果没找到 activeLink，或者它是友情链接，函数自然结束，什么都不做（保持全暗或维持原状）
}

// ==========================================
// Step 3：根据点击事件，动态加载对应的页面
// 核心功能：动态加载菜单栏对应的页面内容
// 作用：点击菜单时，不跳转新页面，而是通过 AJAX (fetch) 把内容“吸”到当前页
// ==========================================
function loadPage(sectionId) {

    // 尝试从映射表中获取，如果找不到则使用默认路径
    var filePath = PAGE_PATH_MAP[sectionId] || DEFAULT_PAGE_PATH;

    // 【定位容器】在 HTML 中找到 ID 为 sectionId 的 <section> 标签（这是放内容的地方）
    let section = document.getElementById(sectionId);

    // 【容错处理】如果页面上根本没有这个 section，打印错误并停止运行，防止后续代码报错
    if (!section) {
        console.error(`❌ Erro: Unable to find ID: "${sectionId}" 's section element.`);
        return;
    }

    // 【用户反馈】在内容加载出来之前，先显示一个“加载中...”的提示，避免用户看到空白
    section.innerHTML = '<div class="loading-text">🔄 Loading the Text...</div>';

     // 【发起请求】使用 fetch API 请求 filePath 指定的文件
    // { cache: 'no-store' }：强制浏览器不要读缓存，每次都去服务器拿最新的内容（适合频繁更新的页面）
    fetch(filePath, { cache: 'no-store' }) 
    .then(response => {

        // 【检查状态】如果网络请求失败（比如 404 文件或 500 服务器错误）
        if (!response.ok) {

            // 抛出一个错误对象，跳到下面的 .catch() 处理
            throw new Error(`HTTP Erro! Stutas Code: ${response.status}`);
        }
        // 如果成功，把响应体转换为纯文本 (html 字符串)
        return response.text();
    })
    .then(html => {
        // 【注入内容】把下载好的 html 字符串填入到 <section> 中，替换掉刚才的“加载中...”
        section.innerHTML = html;
        console.log(`📥 Loaded: ${filePath}`);
        // 【联动高亮】内容加载完后，调用上面的工具函数，确保菜单高亮状态正确
        updateActiveLink(sectionId);
        
        // 【同步地址栏】修改浏览器地址栏的哈希值 (例如变成 #home)
        // 这样用户刷新页面或分享链接时，能直接定位到这个位置
        // 判断：只有当当前地址栏不是这个哈希时，才修改（避免不必要的历史记录堆积）
        if (window.location.hash !== '#' + sectionId) {
            window.location.hash = sectionId;
        }
    })
    .catch(error => {

        // 【错误处理】如果上面任何一步出错（网络断了、文件找不到等），执行这里
        console.error(`💥 Loading Fail:`, error);

        // 【友好提示】把 <section> 的内容换成红色的错误提示框，告诉用户出什么事了
        section.innerHTML = `
            <div style="text-align:center; color:red; padding:50px; border: 2px dashed red;">
                <h3>😢 Loading fail</h3>
                <p><strong>Erro Messages:</strong> ${error.message}</p>
                <p>Target File: ${filePath}</p>
            </div>
        `;
    });
}