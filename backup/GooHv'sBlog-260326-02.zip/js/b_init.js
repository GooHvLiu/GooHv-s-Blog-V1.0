// ==========================================
// 【初始化模块】系统加载并初始化页面
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
    console.log("⚡ [Init] 系统初始化开始...");

    // 【准备数据】获取导航项和板块
    let navItems = document.querySelectorAll(".nav li");
    let sections = document.querySelectorAll("section");

    // --- 功能 1: 点击菜单时的高亮逻辑 ---
    navItems.forEach((item) => {
        item.addEventListener("click", function(e) {
            
            // 【特殊拦截】忽略友情链接容器
            if (this.classList.contains('friend-links-container')) {
                return; 
            }

            // ✅ 阻止默认跳转
            e.preventDefault(); 
            
            // 【手动清场 & 点亮】
            navItems.forEach((i) => i.classList.remove("active"));
            this.classList.add("active");
        });
    });

    // --- 功能 2: 滚动时自动切换高亮 ---
    window.addEventListener('scroll', () => {
        let currentSectionId = '';
        let scrollPosition = window.scrollY || window.pageYOffset;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            // 偏移量 150px，让高亮更顺滑
            if (scrollPosition >= (sectionTop - 150)) {
                currentSectionId = section.getAttribute('id');
            }
        });

        if (currentSectionId && typeof updateActiveLink === 'function') {
            updateActiveLink(currentSectionId);
        }
    });

    // --- 功能 3: 页面初始化时的状态检查 ---
    const initCheck = () => {
        const hash = window.location.hash;
        if (hash) {
            let targetSection = document.querySelector(hash);
            if (targetSection) {
                window.dispatchEvent(new Event('scroll'));
            }
        } else {
            window.dispatchEvent(new Event('scroll'));
        }
    };

    // 【延迟执行】确保布局计算准确
    setTimeout(initCheck, 100);
    
    console.log("✅ [Init] 系统初始化完成。");
});