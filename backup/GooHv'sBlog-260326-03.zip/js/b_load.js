// ==========================================
// 【动态加载模块】核心功能：动态加载菜单栏对应的页面内容
// ==========================================

function loadPage(sectionId) {
    console.log("🚀 [Loader] 开始加载页面:", sectionId);

    // 尝试从映射表中获取路径 (依赖 b_gconfig.js 中的 PAGE_PATH_MAP)
    var filePath = PAGE_PATH_MAP[sectionId] || DEFAULT_PAGE_PATH;

    // 【定位容器】
    let section = document.getElementById(sectionId);

    if (!section) {
        console.error(`❌ [Loader] 错误: 找不到 ID 为 "${sectionId}" 的 section 元素。`);
        return;
    }

    // 【用户反馈】显示加载中
    section.innerHTML = '<div class="loading-text">🔄 Loading the Text...</div>';

    // 【发起请求】
    fetch(filePath, { cache: 'no-store' }) 
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP 错误! 状态码: ${response.status}`);
        }
        return response.text();
    })
    .then(html => {
        // 【注入内容】
        section.innerHTML = html;
        
        // 【联动高亮】调用 b_hightlight.js 中的函数
        if (typeof updateActiveLink === 'function') {
            updateActiveLink(sectionId);
        }
        
        // 【同步地址栏】
        if (window.location.hash !== '#' + sectionId) {
            window.location.hash = sectionId;
        }
    })
    .catch(error => {
        console.error(`💥 [Loader] 加载失败:`, error);
        section.innerHTML = `
            <div style="text-align:center; color:red; padding:50px; border: 2px dashed red;">
                <h3>😢 加载失败</h3>
                <p><strong>错误信息:</strong> ${error.message}</p>
                <p>目标文件: ${filePath}</p>
            </div>
        `;
    });
}