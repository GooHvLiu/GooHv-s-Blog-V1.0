// ==========================================
// 【初始化模块】系统加载并初始化页面 (预加载版)
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
    console.log("⚡ [Init] 系统初始化开始 (预加载模式)...");

    // 【准备数据】
    let navItems = document.querySelectorAll(".nav li");
    let sections = document.querySelectorAll("section");

    // --- 功能 1: 点击菜单时的高亮逻辑 (保持不变) ---
    navItems.forEach((item) => {
        item.addEventListener("click", function(e) {
            if (this.classList.contains('friend-links-container')) return;
            e.preventDefault(); 
            navItems.forEach((i) => i.classList.remove("active"));
            this.classList.add("active");
            
            // 点击时，如果还没加载好（极小概率），强制刷新一下该区域
            const targetId = this.querySelector('a')?.getAttribute('href')?.substring(1);
            if(targetId && typeof loadPage === 'function') {
                // 这里可以加一个判断，如果已加载就不需要再做啥，或者强制刷新
                // 为了简单，我们依赖预加载，点击主要为了高亮和跳转锚点
                window.location.hash = targetId;
            }
        });
    });

    // --- 功能 2: 滚动时仅负责高亮 (不再负责加载！) ---
    // 这样滚动性能最高，没有任何 JS 计算负担
    window.addEventListener('scroll', () => {
        let currentSectionId = '';
        let scrollPosition = window.scrollY || window.pageYOffset;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            if (scrollPosition >= (sectionTop - 150)) {
                currentSectionId = section.getAttribute('id');
            }
        });

        if (currentSectionId && typeof updateActiveLink === 'function') {
            updateActiveLink(currentSectionId);
        }
    });

    // --- 功能 3: 【核心修改】启动时一次性预加载所有内容 ---
    const preloadAllPages = () => {
        console.log("📦 [Preload] 开始预加载所有页面内容...");
        
        // 遍历配置表中的所有 key (my-home, full-stacked, etc.)
        // 注意：PAGE_PATH_MAP 在 b_gconfig.js 中定义
        if (typeof PAGE_PATH_MAP !== 'undefined') {
            Object.keys(PAGE_PATH_MAP).forEach(sectionId => {
                // 调用加载函数，并传入 true 表示是“静默预加载”
                if (typeof loadPage === 'function') {
                    loadPage(sectionId, true); 
                }
            });
        } else {
            console.error("❌ [Preload] 错误：未找到 PAGE_PATH_MAP 配置。");
        }

        // 预加载启动后，再检查 URL Hash 进行定位
        handleInitialHash();
    };

    // 处理初始 Hash 定位
    const handleInitialHash = () => {
        const hash = window.location.hash;
        if (hash) {
            const targetId = hash.substring(1);
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                // 稍微延迟一点执行滚动高亮，确保内容已经注入
                setTimeout(() => {
                    window.dispatchEvent(new Event('scroll'));
                    // 平滑滚动到该位置
                    targetSection.scrollIntoView({ behavior: 'smooth' });
                }, 300);
            }
        } else {
            // 默认触发一次高亮
            setTimeout(() => window.dispatchEvent(new Event('scroll')), 300);
        }
    };

    // 启动预加载
    // 延迟 100ms 确保 DOM 就绪
    setTimeout(preloadAllPages, 100);
    
    console.log("✅ [Init] 初始化完成，所有内容正在后台预加载。");
});